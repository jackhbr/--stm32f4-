package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bean.Msg;
import com.bean.User;
import com.service.IUserService;

/**
 * 处理员工信息CRUD请求
 * 
 * @author copywang
 *
 */
@Controller
public class UserController {
	@Autowired
	IUserService IUserService;// 这里使用的是接口，它会自动创建它的实现类的实例

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	@ResponseBody
	@Transactional
	public Msg login(@RequestParam("username") String username, @RequestParam("password") String password) {
		System.out.println("进入login   输入的用户名和密码是" + username + "   " + password);
		if (username == null || "".equals(username) || password == null || "".equals(password)) {
			return Msg.fail().add("meg", "输入中有一项为空");
		}

		try {
			User user = IUserService.login(username, password);
			System.out.println(user);
			Boolean flag = false;
			if (user != null) {
				flag = true;
			}
			if (flag == true)
				return Msg.success().add("meg", "success");
			else {
				return Msg.fail().add("meg", "不存在该用户");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); // 这里难道时要抛出异常的404界面？？？
			return Msg.fail().add("meg", "系统异常");
		}

	}


}
