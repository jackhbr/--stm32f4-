package com.example.registerandlogin.bean;

public class Msg {

	public int code;

	public String msg;

	public Extend extend;

	public class Extend {
		public String meg;
	}
	
	
}
