package com.example.registerandlogin.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.registerandlogin.R;
import com.example.registerandlogin.bean.Msg;
import com.example.registerandlogin.utils.HttpUtil;
import com.example.registerandlogin.utils.ThreadPoolUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class LoginSuccessActivity extends AppCompatActivity {
    private Button button1;
    private Button button2;
    private Button button3;
    private ArrayList<Button> buttonList;
    public static final int WG = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_success);
        findAllViews();
        setListeners();

        buttonList=new ArrayList<>();
        buttonList.add(button1);
        buttonList.add(button2);
        buttonList.add(button3);


        ThreadPoolUtils.threadPool.submit(new Runnable() {
            @Override
            public void run() {
                String  target = HttpUtil.IP+ "/wgnum";
                URL url;
                try {
                    url = new URL(target);
                    HttpURLConnection urlConn = (HttpURLConnection) url
                            .openConnection();	//创建一个HTTP连接
                    InputStreamReader in = new InputStreamReader(
                            urlConn.getInputStream()); // 获得读取的内容
                    BufferedReader buffer = new BufferedReader(in); // 获取输入流对象
                    String inputLine = null;
                    StringBuilder response =new StringBuilder();
                    //通过循环逐行读取输入流中的内容
                    while ((inputLine = buffer.readLine()) != null) {
                        response.append(inputLine);
                    }
                    Log.d("myapp","wg 返回 "+response.toString());
                    Message message=new Message();
                    message.what=WG;
                    //将服务器返回的结果存放到Message中
                    message.obj=response.toString();
                    handler.sendMessage(message);

                    in.close();	//关闭字符输入流对象
                    urlConn.disconnect();	//断开连接
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    private void findAllViews(){
        button1=findViewById(R.id.wg1Button);
        button2=findViewById(R.id.wg2Button);
        button3=findViewById(R.id.wg3Button);

    }
    private  void setListeners(){
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                HttpUtil.setWgkind(button1.getText().toString());
                //            intent.putExtra("wgkind",button1.getText().toString());
                intent.setClass(LoginSuccessActivity.this, ZdActivity.class);//指定传递对象
                startActivity(intent);

            }
        });

    }


    private Handler handler=new Handler(){
        public void   handleMessage(Message msg){
            switch (msg.what){
                case WG:
                    String result=(String) msg.obj;
                    if (result!= null) {
                        Msg message= ThreadPoolUtils.gson.fromJson(result,Msg.class);
                        if(message.code==100){
                            Log.d("myapp","getwgnum success return "+message);
                            String wgmsg=message.extend.meg;
                            String[] allString=wgmsg.split("!");
                            String[] normalString=allString[0].split("#");
                            String[] unnormalString=allString[1].split("#");
                            int i=0;
                            for(Button button :buttonList){
                                if(i<normalString.length){
                                    button.setText(normalString[i]);
                                    button.setBackgroundColor(Color.GREEN);
                                }else if(i>=normalString.length && i<normalString.length+unnormalString.length) {
                                    button.setText(unnormalString[i-normalString.length]);
                                    button.setBackgroundColor(Color.RED);
                                }else{
                                    break;
                                }
                                i++;
                            }
                        }
                    }
                    break;
            }

        }
    };
}
