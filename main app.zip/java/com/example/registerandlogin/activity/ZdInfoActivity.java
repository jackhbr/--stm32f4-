package com.example.registerandlogin.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.example.registerandlogin.R;
import com.example.registerandlogin.bean.Msg;
import com.example.registerandlogin.bean.Zd;
import com.example.registerandlogin.utils.HttpUtil;
import com.example.registerandlogin.utils.ThreadPoolUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ZdInfoActivity extends AppCompatActivity {

    private TextView tvtemp;
    private TextView tvtitle;
    private TextView tvhum;
    private Switch switch1;
    public static final int ON = 1;
    public static final int OFF = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zd_info);
        Intent intent =getIntent();
        Zd zd=(Zd)intent.getSerializableExtra("zdobj");
        Log.d("myapp",zd.toString());

        findAllViews();
        setListeners();

        tvtitle.setText(HttpUtil.getZdkind());
        tvtemp.setText(zd.getTemperature());
        tvhum.setText(zd.getHumidity());

        Log.d("myapp","onzero= "+zd.getOnzero());
        if(zd.getOnzero().equals("1")){
            Log.d("myapp","阀门开着");
            switch1.setChecked(true);
        }else {
            Log.d("myapp","阀门关了");
            switch1.setChecked(false);
        }

    }

    private void findAllViews(){
        switch1=findViewById(R.id.switch1);
        tvhum=findViewById(R.id.humtv);
        tvtemp=findViewById(R.id.temptv);
        tvtitle=findViewById(R.id.zd1tv);
    }
    private void setListeners(){
        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Log.d("myapp","开着");

                    ThreadPoolUtils.threadPool.submit(new Runnable() {
                        @Override
                        public void run() {
                            String data="wgname="+HttpUtil.getWgkind()+"&zdname="+HttpUtil.getZdkind()+"&onvalue=1";
                            String  target = HttpUtil.IP+ "/setonvalue?"+data;

                            URL url;
                            try {
                                url = new URL(target);
                                HttpURLConnection urlConn = (HttpURLConnection) url
                                        .openConnection();	//创建一个HTTP连接

                                InputStreamReader in = new InputStreamReader(
                                        urlConn.getInputStream()); // 获得读取的内容
                                BufferedReader buffer = new BufferedReader(in); // 获取输入流对象
                                String inputLine = null;
                                StringBuilder response =new StringBuilder();
                                //通过循环逐行读取输入流中的内容
                                while ((inputLine = buffer.readLine()) != null) {
                                    response.append(inputLine);
                                }
                                Log.d("myapp","zd 返回 "+response.toString());
                                Message message=new Message();
                                message.what=ON;
                                //将服务器返回的结果存放到Message中
                                message.obj=response.toString();
                                handler.sendMessage(message);

                                in.close();	//关闭字符输入流对象
                                urlConn.disconnect();	//断开连接
                            } catch (MalformedURLException e) {
                                e.printStackTrace();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                }else {
                    Log.d("myapp","关了");

                    ThreadPoolUtils.threadPool.submit(new Runnable() {
                        @Override
                        public void run() {
                            String data="wgname="+HttpUtil.getWgkind()+"&zdname="+HttpUtil.getZdkind()+"&onvalue=0";
                            String  target = HttpUtil.IP+ "/setonvalue?"+data;

                            URL url;
                            try {
                                url = new URL(target);
                                HttpURLConnection urlConn = (HttpURLConnection) url
                                        .openConnection();	//创建一个HTTP连接

//                                  urlConn.setRequestMethod("POST");
//                                urlConn.setReadTimeout(10000);
//                                urlConn.setConnectTimeout(10000);
//                                urlConn.setDoOutput(true);
//                                urlConn.setDoInput(true);
//                                urlConn.setUseCaches(false);
//                                OutputStream out=urlConn.getOutputStream();
//                                out.write(data.getBytes());
//                                out.flush();


                                InputStreamReader in = new InputStreamReader(
                                        urlConn.getInputStream()); // 获得读取的内容
                                BufferedReader buffer = new BufferedReader(in); // 获取输入流对象
                                String inputLine = null;
                                StringBuilder response =new StringBuilder();
                                //通过循环逐行读取输入流中的内容
                                while ((inputLine = buffer.readLine()) != null) {
                                    response.append(inputLine);
                                }
                                Log.d("myapp","zd 返回 "+response.toString());
                                Message message=new Message();
                                message.what=OFF;
                                //将服务器返回的结果存放到Message中
                                message.obj=response.toString();
                                handler.sendMessage(message);

                                in.close();	//关闭字符输入流对象
                                urlConn.disconnect();	//断开连接
                            } catch (MalformedURLException e) {
                                e.printStackTrace();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                }
            }
        });
    }


    private Handler handler=new Handler(){
        public void   handleMessage(Message msg){
            switch (msg.what){
                case ON:
                    String result=(String) msg.obj;
                    if (result!= null) {
                        Msg message= ThreadPoolUtils.gson.fromJson(result,Msg.class);
                        if(message.code==100){
                            Log.d("myapp","打开成功");
                        }
                    }
                    break;
                case OFF:
                    String result1=msg.obj.toString();
                    Msg message1 = ThreadPoolUtils.gson.fromJson(result1, Msg.class);
                    if(message1.code==100){
                        Log.d("myapp","关闭成功");
                    }else {
                        Log.d("myapp","返回失败");
                    }

                    break;
            }

        }
    };

}
