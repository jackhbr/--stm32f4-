package com.example.registerandlogin.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.registerandlogin.R;
import com.example.registerandlogin.bean.Msg;
import com.example.registerandlogin.utils.HttpUtil;
import com.example.registerandlogin.utils.ThreadPoolUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private Button loginBtn;
    private EditText  usernameEdt;
    private EditText  passwordEdt;
    private String username;
    private String password;
    public static final int LOGIN = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findAllViews();
        setListeners();
    }

    private  void findAllViews(){
        loginBtn=findViewById(R.id.loginButton);
        usernameEdt=findViewById(R.id.username);
        passwordEdt=findViewById(R.id.password);
    }
    private void setListeners(){
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("myapp","按下登录按钮");
                username=usernameEdt.getText().toString();
                password=passwordEdt.getText().toString();
                ThreadPoolUtils.threadPool.submit(new Runnable() {
                    @Override
                    public void run() {
                        String  target = HttpUtil.IP+ "/login?username="+username.trim()+"&password="+password.trim();	//要访问的URL地址
                        URL url;
                        try {
                            url = new URL(target);
                            HttpURLConnection urlConn = (HttpURLConnection) url
                                    .openConnection();	//创建一个HTTP连接
                            InputStreamReader in = new InputStreamReader(
                                    urlConn.getInputStream()); // 获得读取的内容
                            BufferedReader buffer = new BufferedReader(in); // 获取输入流对象
                            String inputLine = null;
                            StringBuilder response =new StringBuilder();
                            //通过循环逐行读取输入流中的内容
                            while ((inputLine = buffer.readLine()) != null) {
                                response.append(inputLine);
                            }
                            Log.d("myapp","login 返回 "+response.toString());
                            Message message=new Message();
                            message.what=LOGIN;
                            //将服务器返回的结果存放到Message中
                            message.obj=response.toString();
                            handler.sendMessage(message);

                            in.close();	//关闭字符输入流对象
                            urlConn.disconnect();	//断开连接
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
    }


    private Handler handler=new Handler(){
      public void   handleMessage(Message msg){
          switch (msg.what){
              case LOGIN:
                  String result=(String) msg.obj;
                  if (result!= null) {
                      Msg message=ThreadPoolUtils.gson.fromJson(result,Msg.class);
                      if(message.code==100){
                          Log.d("myapp","login success return "+message);
                          Intent intent=new Intent();
                          intent.setClass(MainActivity.this, LoginSuccessActivity.class);//指定传递对象
                          startActivity(intent);//将intent传递给activity
                      }
                  }
                  break;
          }

      }
    };

}
