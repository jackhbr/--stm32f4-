package com.example.registerandlogin.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.registerandlogin.R;
import com.example.registerandlogin.bean.Msg;
import com.example.registerandlogin.bean.Zd;
import com.example.registerandlogin.utils.HttpUtil;
import com.example.registerandlogin.utils.ThreadPoolUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class ZdActivity extends AppCompatActivity {
    private Button button1;
    private Button button2;
    public static final int MAINUI = 0;
    public static final int BUTTON1 = 1;
    public static final int BUTTON2 = 2;
    private ArrayList<Button> buttonList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zd);

        findAllViews();
        setListeners();

        buttonList = new ArrayList<>();
        buttonList.add(button1);
        buttonList.add(button2);



        ThreadPoolUtils.threadPool.submit(new Runnable() {
            @Override
            public void run() {
                String  target = HttpUtil.IP+ "/zdnum?wgname="+HttpUtil.getWgkind();
                URL url;
                try {
                    url = new URL(target);
                    HttpURLConnection urlConn = (HttpURLConnection) url
                            .openConnection();	//创建一个HTTP连接
                    InputStreamReader in = new InputStreamReader(
                            urlConn.getInputStream()); // 获得读取的内容
                    BufferedReader buffer = new BufferedReader(in); // 获取输入流对象
                    String inputLine = null;
                    StringBuilder response =new StringBuilder();
                    //通过循环逐行读取输入流中的内容
                    while ((inputLine = buffer.readLine()) != null) {
                        response.append(inputLine);
                    }
                    Log.d("myapp","zd 返回 "+response.toString());
                    Message message=new Message();
                    message.what=MAINUI;
                    //将服务器返回的结果存放到Message中
                    message.obj=response.toString();
                    handler.sendMessage(message);

                    in.close();	//关闭字符输入流对象
                    urlConn.disconnect();	//断开连接
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void   findAllViews(){
        button1 = findViewById(R.id.zd1Button);
        button2 = findViewById(R.id.zd2Button);
    }
    private void setListeners(){
        button1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               new Thread(new Runnable() {
                   @Override
                   public void run() {
                       HttpURLConnection connection = null;
                       try {
                           Log.d("myapp","button1 "+button1.getText().toString());
                           URL url = new URL(HttpUtil.IP+"/zdinfo?wgname="+HttpUtil.getWgkind()+"&zdname="+button1.getText().toString());
                           HttpUtil.setZdkind(button1.getText().toString());
                           connection = (HttpURLConnection) url.openConnection();
                           if (connection.getResponseCode() == 200) {
                               Log.d("myapp","连接成功了");
                           } else {
                               Log.d("myapp","连接失败了");
                           }
                           InputStream in = connection.getInputStream();
                           //对获取到的输入流进行读取
                           BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                           StringBuilder response = new StringBuilder();
                           String line;
                           while ((line = reader.readLine()) != null) {
                               response.append(line);
                           }
                           Log.d("myapp","zdinfo返回为 "+response.toString());
                           Message message = new Message();
                           message.what = BUTTON1;
                           //将服务器返回的结果存放到Message中
                           message.obj = response.toString();
                           handler.sendMessage(message);
                       } catch (Exception e) {
                           e.printStackTrace();
                       } finally {
                           if (connection != null) {
                               connection.disconnect();
                           }
                       }
                   }
               }).start();

           }
       }
        );

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        HttpURLConnection connection = null;
                        try {
                            URL url = new URL(HttpUtil.IP+"/zdinfo?wgname="+HttpUtil.getWgkind()+"&zdname="+button2.getText().toString());
                            HttpUtil.setZdkind(button2.getText().toString());
                            connection = (HttpURLConnection) url.openConnection();
                            if (connection.getResponseCode() == 200) {
                                Log.d("myapp","连接成功了");
                            } else {
                                Log.d("myapp","连接失败了");
                            }
                            InputStream in = connection.getInputStream();
                            //对获取到的输入流进行读取
                            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                            StringBuilder response = new StringBuilder();
                            String line;
                            while ((line = reader.readLine()) != null) {
                                response.append(line);
                            }
                            Log.d("myapp","zdinfo返回为 "+response.toString());
                            Message message = new Message();
                            message.what = BUTTON2;
                            //将服务器返回的结果存放到Message中
                            message.obj = response.toString();
                            handler.sendMessage(message);
                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            if (connection != null) {
                                connection.disconnect();
                            }
                        }
                    }
                }).start();
            }
        });
    }

    private Handler handler=new Handler(){
        public void   handleMessage(Message msg){
            switch (msg.what){
                case MAINUI:
                    String result=(String) msg.obj;
                    if (result!= null) {
                        Msg message= ThreadPoolUtils.gson.fromJson(result,Msg.class);
                        if(message.code==100){
                            String zdmsg=message.extend.meg;
                            String[] allString = zdmsg.split("!");
                            String[] normalString = allString[0].split("#");
                            int i = 0;
                            for (Button button : buttonList) {
                                if (i < normalString.length) {
                                    button.setText(normalString[i]);
                                    button.setBackgroundColor(Color.GREEN);
                                }else {
                                    break;
                                }
                                i++;
                            }

                        }
                    }
                    break;
                case BUTTON1:
                    String result1=msg.obj.toString();
                    Msg message1 = ThreadPoolUtils.gson.fromJson(result1, Msg.class);
                    if(message1.code==100){
                        String zdinfo = message1.extend.meg;
                        String[] info = zdinfo.split("#");
                        Zd zd=new Zd();
                        zd.setTemperature(info[0]);
                        zd.setHumidity(info[1]);
                        zd.setOnzero(info[2]);

                        Log.d("myapp","返回zd "+zd.toString());

                        Intent intent=new Intent();
                        intent.putExtra("zdobj",zd);
                        intent.setClass(ZdActivity.this,ZdInfoActivity.class);
                        startActivity(intent);

                    }else {
                        Log.d("myapp","返回失败");
                    }

                    break;
                case  BUTTON2:
                    String result2=msg.obj.toString();
                    Msg message2 = ThreadPoolUtils.gson.fromJson(result2, Msg.class);
                    if(message2.code==100){
                        String zdinfo = message2.extend.meg;
                        String[] info = zdinfo.split("#");
                        Zd zd=new Zd();
                        zd.setTemperature(info[0]);
                        zd.setHumidity(info[1]);
                        zd.setOnzero(info[2]);

                        Log.d("myapp","返回zd "+zd.toString());
                        Intent intent=new Intent();
                        intent.putExtra("zdobj",zd);
                        intent.setClass(ZdActivity.this,ZdInfoActivity.class);
                        startActivity(intent);

                    }else {
                        Log.d("myapp","返回失败");
                    }
                    break;
            }

        }
    };
}