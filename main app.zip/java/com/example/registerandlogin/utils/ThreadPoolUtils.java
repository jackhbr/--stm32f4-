package com.example.registerandlogin.utils;

import com.google.gson.Gson;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPoolUtils {

    public static  ExecutorService threadPool;
    public static Gson gson;

    static {
        threadPool = Executors.newCachedThreadPool();
        gson=new Gson();
    }
}
