package com.example.registerandlogin.utils;

public class HttpUtil {
    public static final String IP="http://175.10.106.245:80";

    public static String wgkind="";
    public static String zdkind="";

    public static String getWgkind() {
        return wgkind;
    }

    public static void setWgkind(String wgkind) {
        HttpUtil.wgkind = wgkind;
    }

    public static String getZdkind() {
        return zdkind;
    }

    public static void setZdkind(String zdkind) {
        HttpUtil.zdkind = zdkind;
    }
}
