package com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.User;
import com.dao.UserMapper;
import com.service.IUserService;

import java.util.List;

@Service
public class UserServiceImpl implements IUserService {
	@Autowired
	private UserMapper userMapper;

	@Override
	public User login(String name, String password) {
		User user = userMapper.findUserByNameAndPwd(name, password);
		return user;
	}

	public String getWg(){
		StringBuffer result=new StringBuffer();
		List<String> list1= userMapper.selectNormal();
		for(String i:list1){
			result.append(i).append("#");
		}
		result.deleteCharAt(result.length()-1);
		result.append("!");
		List<String> list2=userMapper.selectUnNormal();
		for(String i:list2){
			result.append(i).append("#");
		}
		result.deleteCharAt(result.length()-1);
		return  result.toString();
	}

}
