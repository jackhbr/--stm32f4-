package com.dao;

import org.apache.ibatis.annotations.Param;

import com.bean.User;

import java.util.List;

public interface UserMapper {
	// @param是把这里的的参数传到xml中，等到xml中就是直接用@param里面的东西
	public User findUserByNameAndPwd(@Param("username") String username, @Param("password") String password);

	public List<String> selectNormal();

	public  List<String> selectUnNormal();


}
