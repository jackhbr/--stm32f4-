package com.bean;


public class User {

	private String username;

	private String password;

	public User(String trueName, String password) {
		super();
		this.username = trueName;
		this.password = password;
	}

	public String getUserName() {
		return username;
	}

	public void setUserName(String trueName) {
		this.username = trueName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [UserName=" + username + ", password=" + password + "]";
	}

}