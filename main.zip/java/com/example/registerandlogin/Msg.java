package com.example.registerandlogin;

public class Msg {

	public int code;

	public String msg;

	public class extend {
		public String msg;
	}
	
	
}
