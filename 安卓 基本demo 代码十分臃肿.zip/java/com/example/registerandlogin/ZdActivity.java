package com.example.registerandlogin;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ZdActivity extends AppCompatActivity {
    private Handler handler;
    private String wgkind = "";
    private TextView logText;
    private Button button1;
    private Button button2;
    public static final int MAINUI = 0;
    public static final int BUTTON1 = 1;
    public static final int BUTTON2 = 2;
    Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zd);

        Intent receiveIntent = getIntent();
        wgkind = receiveIntent.getStringExtra("wgkind");
        Log.d("myapp","获取的wgkind= "+wgkind);


        logText = findViewById(R.id.txtOne);
        button1 = findViewById(R.id.Button1);
        button2 = findViewById(R.id.Button2);

        final List<Button> buttonList = new ArrayList<>();
        buttonList.add(button1);
        buttonList.add(button2);

        button1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               new Thread(new Runnable() {
                   @Override
                   public void run() {
                       HttpURLConnection connection = null;
                       try {
                           Log.d("myapp","button1 "+button1.getText().toString());
                           URL url = new URL("http://175.10.106.61/zdinfo?wgname="+wgkind+"&zdname="+button1.getText().toString());
                           connection = (HttpURLConnection) url.openConnection();
//                           connection.setDoOutput(true);
//                           connection.setDoInput(true);
//                           connection.setRequestMethod("GET");
//                           connection.setConnectTimeout(8000);
//                           connection.setReadTimeout(8000);
//                           connection.setRequestProperty("Charset", "UTF-8");
//                           connection.setRequestProperty("contentType", "application/json");
                           if (connection.getResponseCode() == 200) {
                               Log.d("myapp","连接成功了");
                           } else {
                               Log.d("myapp","连接失败了");
                           }
                           InputStream in = connection.getInputStream();
                           //对获取到的输入流进行读取
                           BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                           StringBuilder response = new StringBuilder();
                           String line;
                           while ((line = reader.readLine()) != null) {
                               response.append(line);
                           }
                           Log.d("myapp","返回为 "+response.toString());
                           Message message = new Message();
                           message.what = BUTTON1;
                           //将服务器返回的结果存放到Message中
                           message.obj = response.toString();
                           handler.sendMessage(message);
                       } catch (Exception e) {
                           e.printStackTrace();
                       } finally {
                           if (connection != null) {
                               connection.disconnect();
                           }
                       }
                   }
               }).start();

           }
        }
        );

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        HttpURLConnection connection = null;
                        try {
                            URL url = new URL("http://175.10.106.61/zdinfo?wgname="+wgkind+"&zdname="+button2.getText().toString());
                            connection = (HttpURLConnection) url.openConnection();
                            connection.setDoOutput(true);
                            connection.setDoInput(true);
                            connection.setRequestMethod("GET");
                            connection.setConnectTimeout(8000);
                            connection.setReadTimeout(8000);
                            connection.setRequestProperty("Charset", "UTF-8");
                            connection.setRequestProperty("contentType", "application/json");
                            if (connection.getResponseCode() == 200) {
                                Log.d("myapp","连接成功了");
                            } else {
                                Log.d("myapp","连接失败了");
                            }
                            InputStream in = connection.getInputStream();
                            //对获取到的输入流进行读取
                            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                            StringBuilder response = new StringBuilder();
                            String line;
                            while ((line = reader.readLine()) != null) {
                                response.append(line);
                            }
                            Log.d("myapp","返回为 "+response.toString());
                            Message message = new Message();
                            message.what = BUTTON2;
                            //将服务器返回的结果存放到Message中
                            message.obj = response.toString();
                            handler.sendMessage(message);
                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            if (connection != null) {
                                connection.disconnect();
                            }
                        }
                    }
                }).start();
            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {
                    Log.d("myapp","开始zdnum的访问");
                    URL url = new URL("http://175.10.106.61/zdnum?wgname="+wgkind);
                    connection = (HttpURLConnection) url.openConnection();
//                    connection.setDoOutput(true);
//                    connection.setDoInput(true);
//                    connection.setRequestMethod("GET");
//                    connection.setConnectTimeout(8000);
//                    connection.setReadTimeout(8000);
//                    connection.setRequestProperty("Charset", "UTF-8");
//                    connection.setRequestProperty("contentType", "application/json");
                    if (connection.getResponseCode() == 200) {
                           Log.d("myapp","开始zdnum的访问 连接成功了");
                    } else {
                           Log.d("myapp","开始zdnum的访问 连接失败了");
                    }
                    InputStream in = connection.getInputStream();
                    //对获取到的输入流进行读取
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    Log.d("myapp","zdnum的返回 "+response);
                    Message message = new Message();
                    message.what = MAINUI;
                    //将服务器返回的结果存放到Message中
                    message.obj = response.toString();
                    handler.sendMessage(message);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {

                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        }).start();

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                Log.d("myapp","进入zdactivit的 handlemessage "+msg.what+"  "+msg.obj.toString());
                switch (msg.what) {

                    case MAINUI:
                            Log.d("myapp","进入mainui");
                            String result=msg.obj.toString();
                            Msg message = gson.fromJson( result, Msg.class);
                            if (message.code == 100) {
                                Log.d("myapp","进入mainui code=100");
                                String wgmsg = message.extend.meg;
                                Log.d("myapp",wgmsg);
                                String[] allString = wgmsg.split("!");

                                Log.d("myapp", allString.length+"");
                                String[] normalString = allString[0].split("#");



                                int i = 0;
                                for (Button button : buttonList) {
                                    if (i < normalString.length) {
                                        button.setText(normalString[i]);
                                        button.setBackgroundColor(Color.GREEN);
                                    }else {
                                        break;
                                    }
                                    i++;
                                }

                            } else {
                                logText.setText("error number");
                            }
                        break;
                    case BUTTON1:
                        Log.d("myapp","进入button1 ui");
                        String result1=msg.obj.toString();
                        Msg message1 = gson.fromJson(result1, Msg.class);
                        if(message1.code==100){
                            String zdinfo = message1.extend.meg;
                            String[] info = zdinfo.split("#");
                            Zd zd=new Zd();
                            zd.setTemperature(info[0]);
                            zd.setHumidity(info[1]);
                            zd.setOnzero(info[2]);

                            Log.d("t",zd.toString());

                            Intent intent=new Intent();
                            intent.putExtra("zdobj",zd);
                            intent.putExtra("zdname",button1.getText().toString());
                            intent.setClass(ZdActivity.this,ZdInfoActivity.class);
                            startActivity(intent);

                        }else {
                            Log.d("myapp","返回失败");
                        }

                        break;
                    case  BUTTON2:
                        Log.d("myapp","进入button2 ui");
                        String result2=msg.obj.toString();
                        Msg message2 = gson.fromJson(result2, Msg.class);
                        if(message2.code==100){
                            String zdinfo = message2.extend.meg;
                            String[] info = zdinfo.split("#");
                            Zd zd=new Zd();
                            zd.setTemperature(info[0]);
                            zd.setHumidity(info[1]);
                            zd.setOnzero(info[2]);

                            Log.d("myapp",zd.toString());

                            Intent intent=new Intent();
                            intent.putExtra("zdobj",zd);
                            intent.setClass(ZdActivity.this,ZdInfoActivity.class);
                            startActivity(intent);

                        }else {
                            Log.d("myapp","返回失败");
                        }
                        break;

                }

            }
        };
    }
}