package com.example.registerandlogin;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class LoginSuccessActivity extends AppCompatActivity {
    private Handler handler;
    private String result = "";
    private TextView logText;
    private Button button1;
    private Button button2;
    private Button button3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_success);
        logText=findViewById(R.id.txtOne);
        button1=findViewById(R.id.Button1);
        button2=findViewById(R.id.Button2);
        button3=findViewById(R.id.Button3);
        final List<Button> buttonList=new ArrayList<>();
        buttonList.add(button1);
        buttonList.add(button2);
        buttonList.add(button3);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.putExtra("wgkind",button1.getText().toString());
                intent.setClass(LoginSuccessActivity.this,ZdActivity.class);//指定传递对象
                startActivity(intent);

            }
        });

        new Thread(new Runnable() {
            public void run() {
                send();	//发送文本内容到Web服务器
                Message m = handler.obtainMessage(); // 获取一个Message
                handler.sendMessage(m); // 发送消息
            }
        }).start(); // 开启线程

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                if (result != null) {
                    Gson gson=new Gson();
                    Msg message=gson.fromJson(result,Msg.class);
                    if(message.code==100){
                        Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                        String wgmsg=message.extend.meg;

                        Log.d("myapp","login success "+result);

                        String[] allString=wgmsg.split("!");
                        String[] normalString=allString[0].split("#");
                        String[] unnormalString=allString[1].split("#");
                        logText.setText(result+" "+normalString.length+" "+unnormalString.length);
                        int i=0;
                        for(Button button :buttonList){
                            if(i<normalString.length){
                                button.setText(normalString[i]);
                                button.setBackgroundColor(Color.GREEN);
                            }else if(i>=normalString.length && i<normalString.length+unnormalString.length) {
                                button.setText(unnormalString[i-normalString.length]);
                                button.setBackgroundColor(Color.RED);
                            }else{
                                break;
                            }
                            i++;
                        }

                    }else{
                        logText.setText("error number");
                    }

                }
                super.handleMessage(msg);
            }
        };
    }

    public void send() {
        String target="";
        target = "http://175.10.106.61/wgnum";	//要访问的URL地址
        URL url;
        try {
            url = new URL(target);
            HttpURLConnection urlConn = (HttpURLConnection) url
                    .openConnection();	//创建一个HTTP连接
            InputStreamReader in = new InputStreamReader(
                    urlConn.getInputStream()); // 获得读取的内容
            BufferedReader buffer = new BufferedReader(in); // 获取输入流对象
            String inputLine = null;
            //通过循环逐行读取输入流中的内容
            while ((inputLine = buffer.readLine()) != null) {
                result += inputLine + "\n";
            }
            in.close();	//关闭字符输入流对象
            urlConn.disconnect();	//断开连接
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
