package com.example.registerandlogin;

import java.io.Serializable;

public class Zd implements Serializable {

    private static final long serialVersionUID=1L;

    private String temperature;

    private String humidity;

    private  String onzero;

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getOnzero() {
        return onzero;
    }

    public void setOnzero(String onzero) {
        this.onzero = onzero;
    }

    @Override
    public String toString() {
        return "Zd{" +
                "temperature='" + temperature + '\'' +
                ", humidity='" + humidity + '\'' +
                ", onzero='" + onzero + '\'' +
                '}';
    }
}
