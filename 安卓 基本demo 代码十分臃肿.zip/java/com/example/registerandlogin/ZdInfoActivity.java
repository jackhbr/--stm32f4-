package com.example.registerandlogin;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

public class ZdInfoActivity extends AppCompatActivity {

    private TextView tvtemp;
    private TextView tvtitle;
    private TextView tvhum;
    private Switch switch1;
    private String zdname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zd_info);
        Intent intent =getIntent();
        zdname=intent.getStringExtra("zdname");
        Zd zd=(Zd)intent.getSerializableExtra("zdobj");
        Log.d("myapp",zd.toString());
        switch1=findViewById(R.id.switch1);
        tvhum=findViewById(R.id.humtv);
        tvtemp=findViewById(R.id.temptv);
        tvtitle=findViewById(R.id.zd1tv);

        tvtitle.setText(zdname);
        tvtemp.setText(zd.getTemperature());
        tvhum.setText(zd.getHumidity());

        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    Log.d("myapp","开着");
                }else {
                    Log.d("myapp","关了");
                }
            }
        });
        if(zd.getOnzero()=="1"){
            Log.d("myapp","服务器开着");
        }else {
            Log.d("myapp","服务器关了");
        }
    }
}
