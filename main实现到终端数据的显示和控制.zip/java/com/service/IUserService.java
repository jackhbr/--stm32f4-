package com.service;

import com.bean.User;

public interface IUserService {
	// 用户登录
	User login(String name, String password);

	String getWg();

	String getZd(String wgname);

	String getZdInfo(String wgname,String zdname);

	void  setOnValue(String wgname,String onvalue,String zdname);
}
