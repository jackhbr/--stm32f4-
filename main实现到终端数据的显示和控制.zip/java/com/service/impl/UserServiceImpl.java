package com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.User;
import  com.bean.Zd;
import com.dao.UserMapper;
import com.service.IUserService;
import java.util.List;

@Service
public class UserServiceImpl implements IUserService {
	@Autowired
	private UserMapper userMapper;

	@Override
	public User login(String name, String password) {
		User user = userMapper.findUserByNameAndPwd(name, password);
		return user;
	}

	public String getWg(){
		StringBuffer result=new StringBuffer();
		List<String> list1= userMapper.selectNormalWg();
		for(String i:list1){
			result.append(i).append("#");
		}
		result.deleteCharAt(result.length()-1);
		result.append("!");
		List<String> list2=userMapper.selectUnNormalWg();
		for(String i:list2){
			result.append(i).append("#");
		}
		result.deleteCharAt(result.length()-1);
		return  result.toString();
	}

	public String getZd(String wgname){
		StringBuffer result=new StringBuffer();
		List<String> list1= userMapper.selectNormalZd(wgname);
		for(String i:list1){
			result.append(i).append("#");
		}
		result.deleteCharAt(result.length()-1);
		result.append("!");
		List<String> list2=userMapper.selectUnNormalZd(wgname);
		for(String i:list2){
			result.append(i).append("#");
		}
		result.deleteCharAt(result.length()-1);
		return  result.toString();
	}

	public String getZdInfo(String wgname,String zdname){
		Zd zd=userMapper.selectZdData(wgname,zdname);
		System.out.println(zd);
		StringBuilder sb=new StringBuilder().append(zd.getTemperature()).append("#").append(zd.getHumidity()).append("#").append(zd.getOnzero());
		return  sb.toString();
	}

	public void setOnValue(String wgname,String onvalue,String zdname){
		userMapper.setOnValue(wgname,onvalue,zdname);
	}

}
