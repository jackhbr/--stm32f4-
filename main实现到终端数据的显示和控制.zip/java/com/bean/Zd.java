package com.bean;

public class Zd {
    private String temperature;

    private String humidity;

    private  String onzero;

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getOnzero() {
        return onzero;
    }

    public void setOnzero(String onzero) {
        this.onzero = onzero;
    }

    @Override
    public String toString() {
        return "Zd{" +
                "temperature='" + temperature + '\'' +
                ", humidity='" + humidity + '\'' +
                ", onzero='" + onzero + '\'' +
                '}';
    }
}
