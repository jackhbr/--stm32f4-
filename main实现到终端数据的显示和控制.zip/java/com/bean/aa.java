package com.bean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class aa {
    static List<String> name = new ArrayList<>(Arrays.asList("xxx","yyy","zzz"));
    public static void main(String[] args) {
        StringBuffer result=new StringBuffer();

        for(String i:name){
            result.append(i).append("#");
        }
        result.deleteCharAt(result.length()-1);
        System.out.println(result);
    }
}
