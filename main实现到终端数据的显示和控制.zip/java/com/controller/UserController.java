package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bean.Msg;
import com.bean.User;
import com.service.IUserService;

import java.util.Date;

/**
 * 处理员工信息CRUD请求
 * 
 * @author copywang
 *
 */
@Controller
public class UserController {
	@Autowired
	IUserService IUserService;// 这里使用的是接口，它会自动创建它的实现类的实例

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	@ResponseBody
	@Transactional
	public Msg login(@RequestParam("username") String username, @RequestParam("password") String password) {
		System.out.println("进入login   输入的用户名和密码是" + username + "   " + password);
		if (username == null || "".equals(username) || password == null || "".equals(password)) {
			return Msg.fail().add("meg", "输入中有一项为空");
		}

		try {
			User user = IUserService.login(username, password);
			System.out.println(user);
			Boolean flag = false;
			if (user != null) {
				flag = true;
			}
			if (flag == true)
				return Msg.success().add("meg", "success");
			else {
				return Msg.fail().add("meg", "不存在该用户");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); // 这里难道时要抛出异常的404界面？？？
			return Msg.fail().add("meg", "系统异常");
		}

	}

	@RequestMapping(value = "/wgnum", method = RequestMethod.GET)
	@ResponseBody
	@Transactional
	public Msg findWg(){
		System.out.println("进入查询网关"+new Date());
		String wg=IUserService.getWg();
		if(wg!=null){
			return Msg.success().add("meg", wg);
		}else {
			return Msg.fail().add("meg", "查询网关失败");
		}
	}

	@RequestMapping(value = "/zdnum", method = RequestMethod.GET)
	@ResponseBody
	@Transactional
	public Msg findZd(@RequestParam("wgname") String wgname){
		System.out.println("进入查询网关"+new Date());
		String wg=IUserService.getZd(wgname);
		if(wg!=null){
			return Msg.success().add("meg", wg);
		}else {
			return Msg.fail().add("meg", "查询网关失败");
		}
	}

	@RequestMapping(value = "/zdinfo", method = RequestMethod.GET)
	@ResponseBody
	@Transactional
	public Msg findZdInfo(@RequestParam("wgname") String wgname,@RequestParam("zdname") String zdname){
		String zdinfo=IUserService.getZdInfo(wgname,zdname);
		if(zdinfo!=null){
			return Msg.success().add("meg", zdinfo);
		}else {
			return Msg.fail().add("meg", "查询网关失败");
		}
	}

	@RequestMapping(value = "/setonvalue", method = RequestMethod.POST)
	@ResponseBody
	@Transactional
	public Msg setOnValue(@RequestParam("wgname") String wgname,@RequestParam("onvalue") String onvalue,@RequestParam("zdname") String zdname){
		System.out.println("进入onvalue set "+new Date());
		IUserService.setOnValue(wgname,onvalue,zdname);
		System.out.println("service 调用完毕");
		return Msg.success().add("meg", "success");
	}


}
